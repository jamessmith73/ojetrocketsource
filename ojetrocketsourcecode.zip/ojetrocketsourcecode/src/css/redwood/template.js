function take_or_set($val, $default) {
  if (typeof $val == 'undefined') {
    return $default;
  } else {
    return $val;
  }
}

$('<div id="fetcher"></div>').appendTo('body');

var months_short = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

$('.template-here').each(function() {
  render_template($(this));
});

function render_template($this) {

  var $id = $this.attr('id');
  var $template_file = take_or_set($this.attr('data-template'), 'template-' + $id + '.html');

  var $limit = take_or_set($this.attr('data-limit'), -1);

  if ($template_file.indexOf("/") >= 0) {
    var $last_slash = $template_file.lastIndexOf("/") + 1;
    var $template_name = $template_file.substr($last_slash);
  } else {
    var $template_name = $template_file;
  }
  //$template_name = $template_name.replace('.html', '');
  $template_name = $template_name.substring(0, $template_name.indexOf('.html'));
  $template_name = $template_name.replace('#', '');
  if ($template_file.indexOf("#") === 0) {
    console.log('================' + $template_file);
    var template = Handlebars.compile($($template_file).html());

    var $value = $this.attr('data-value');
    var $feed = $this.attr('data-feed');

    if (typeof $value !== typeof undefined && $value !== false) {
      $value = window[$value];
      $this.html(template($value));
    } else if (typeof $feed !== typeof undefined && $feed !== false) {
      $.getScript($feed).done(function(script, textStatus) {
        if (script.indexOf('var') == 0 || script.indexOf('feed_data') == 0) {
          console.log('var defined in feed');
        } else {
          console.log('var not defined in feed');
        }
        console.log('--------------');
        console.log('--------------');
        console.log('--------------');
        console.log(script);
        $this.html(template(feed_data));
      });
    }

    console.log("Template is INLINE");
  } else {
    $('<div></div>').appendTo('#fetcher').load($template_file, function(response, status, xhr) {
      if (!$this.hasClass('template-delegate')) {

        console.log("-----------------");
        console.log("Template Path: " + $template_file);
        console.log("Template ID: " + $template_name);

        var template = Handlebars.compile($('#' + $template_name).html());

        var $feed = false;
        $feed = $this.attr('data-feed');

        var $sort = false;
        $sort = $this.attr('data-sort');

        var $sortOrder = false;
        $sortOrder = $this.attr('data-sortOrder');

        var current_url = window.location.href;
        if (current_url.toLowerCase().indexOf('beta') != -1) {
          $feed = $this.attr('data-feed-beta');
          console.log("Template is BETA");
        }
        if (typeof $feed !== typeof undefined && $feed !== false) {
          console.log("Template read data-feed: " + $feed);

          // If RSS
          if ($this.attr('data-type') == "rss") {

            $.get($feed).success(function(data) {
              var $xml = $(data);
              var feed_data = [];
              $xml.find("item").each(function() {
                var $this = $(this);
                feed_data.push({
                  Title: $this.find("title").text(),
                  Link_URL: $this.find("link").text(),
                  Description: $this.find("description").text(),
                  Customer: $this.find("customer").text(),
                  Date: $this.find("displaydate").text(),
                  //author: $this.find("author").text()
                });
              });
              $this.html(template(feed_data));
            }).error(function(jqXHR, textStatus, errorThrown) {
              console.log("-----------------");
              console.log("RSS loading failed");
              console.log($feed);
              console.log(jqXHR);
              console.log(textStatus);
              console.log(errorThrown);

              // Check if fallback feed defined
              if (typeof $this.attr('data-feed-fallback') !== typeof undefined && $this.attr('data-feed-fallback') !== false) {
                $.get($this.attr('data-feed-fallback'), function(data) {

                  console.log("Use local RSS fallback");
                  console.log($this.attr('data-feed-fallback'));
                  var $xml = $(data);
                  var feed_data = [];
                  $xml.find("item").each(function() {
                    var $this = $(this);
                    feed_data.push({
                      Title: $this.find("title").text(),
                      Link_URL: $this.find("link").text(),
                      Description: $this.find("description").text(),
                      Date: $this.find("pubDate").text(),
                      //author: $this.find("author").text()
                    });
                  });
                  $this.html(template(feed_data));
                });
              }
            });
          }

          // if we need to getJson and fetch into a variable
          else if ($this.attr('data-type') == "getJson") {

            $.getJSON($feed, function(json) {
              if (json.hasOwnProperty('items')) {
                $this.html(template(json.items));
              } else {
                $this.html(template(json));
              }
              main_init();
            });
          }
          // If JSON
          else {

            var $checker = 0;
            var $item_checker = 0;
            // If multiple json provided
            if ($feed.indexOf(',') > -1) {
              var $feed_arr = [];

              var $combined_feed = [];
              $.each($feed.split(","), function() {
                $feed_arr.push($.trim(this));
              });


              var $feed_arr_length = $feed_arr.length;
              /*
              if($limit!= -1){
              	$feed_arr_length = $limit;
              }
              */

              var FileNames = [];
              var $feed_arr_total = $feed_arr.length;
              $.each($feed_arr, function(ii, feed_path) {

                FileNames.push(feed_path.split('/').pop());

                $.getScript(feed_path).done(function(script, textStatus) {
                  $checker++;

                  var feed_data_len = feed_data.length;

                  $.each(feed_data, function(index, element) {

                    $item_checker++;

                    var $tidy_feed = element;

                    var $tidy_title = element.title;
                    if (typeof $tidy_title == 'undefined') {
                      $tidy_title = element.Title;
                    }

                    var $tidy_description = element.description;
                    if (typeof $tidy_description == 'undefined') {
                      $tidy_description = element.Description;
                    }

                    var $tidy_image = element.image;
                    if (typeof $tidy_image == 'undefined') {
                      $tidy_image = element.Image;
                    }

                    if (typeof $tidy_image !== 'undefined') {
                      $tidy_image = feed_path.substr(0, feed_path.lastIndexOf("/")) + '/images/' + $tidy_image;
                      $tidy_feed.Image = $tidy_image;
                    } else {
                      $tidy_image = element.Images;

                      var $tidy_image_arr = [];
                      $.each($tidy_image, function(i, $single_img) {
                        var $single_img_trim = $single_img.trim();
                        if ($single_img_trim != '') {
                          $tidy_image_arr.push(feed_path.substr(0, feed_path.lastIndexOf("/")) + '/images/' + $single_img_trim);
                        }
                      });
                      $tidy_feed.Images = $tidy_image_arr;
                    }

                    var $tidy_link = element.link;
                    if (typeof $tidy_link == 'undefined') {
                      $tidy_link = element.Link_URL;
                    }

                    var $tidy_date = element.pubDate;
                    if (typeof $tidy_date == 'undefined') {
                      $tidy_date = element.Date;
                    }

                    if ($tidy_date == '') {
                      $tidy_date = 0;
                    } else {
                      var formattedDate = new Date($('<span>' + $tidy_date + '</span>').text());

                      var d = formattedDate.getDate();
                      var m = formattedDate.getMonth(); // JavaScript months are 0-11
                      var y = formattedDate.getFullYear();

                      if (isNaN(d) || isNaN(y) || typeof m == 'undefined') {
                        $tidy_date = element.Date;
                      } else {
                        $tidy_date = d + " " + monthNames[m] + " " + y;
                      }
                    }

                    $tidy_feed.FileName = feed_path.split('/').pop();
                    $tidy_feed.Title = $tidy_title;
                    $tidy_feed.Description = $tidy_description;
                    $tidy_feed.Link_URL = $tidy_link;
                    $tidy_feed.Date = $tidy_date;


                    if ($tidy_title != '' && $tidy_title != ' ' && typeof $tidy_title != 'undefined') {
                      $combined_feed.push($tidy_feed);
                    }

                  });

                  // if it is last item, run the templating
                  if ($checker == $feed_arr_length) {




                    if ($combined_feed[0].Date) {
                      $combined_feed.sort(function(a, b) {
                        // Turn your strings into dates, and then subtract them
                        // to get a value that is either negative, positive, or zero.
                        var x = a.Date;
                        var y = b.Date;

                        var b = Math.round((new Date(y)).getTime() / 1000);
                        var a = Math.round((new Date(x)).getTime() / 1000);

                        if (typeof a == 'undefined' || isNaN(a)) {
                          console.log('isNaN');
                          console.log(new Date(a.Date));
                          a = Math.round((new Date('01 ' + x)).getTime() / 1000);
                        }
                        if (typeof b == 'undefined' || isNaN(b)) {
                          b = Math.round((new Date('01 ' + y)).getTime() / 1000);
                        }


                        return b - a;
                      });
                    } else {
                      if ($this.attr('data-multi-load-first-row') == 'balance') {
                        var $category = $this.attr('data-category');
                        var $categoryDiffHandle = [0];
                        var $categoryDiffSorted = [];

                        // get the array key, of first occurence of difference category
                        $.each($combined_feed, function(i, v) {
                          if (i > 0 && (v[$category] !== $combined_feed[i - 1][$category])) {
                            $categoryDiffHandle.push(i);
                          }
                        });

                        // with that array key, split diff category nicely into a new array
                        var $largestChildNum = 0;
                        $.each($categoryDiffHandle, function(i, v) {
                          var $currentSlice = false;
                          if (i != $categoryDiffHandle.length - 1) {
                            $currentSlice = $combined_feed.slice(v, $categoryDiffHandle[i + 1]);
                            $categoryDiffSorted.push($currentSlice);
                          }
                          if (i == $categoryDiffHandle.length - 1) {
                            $currentSlice = $combined_feed.slice(v, $categoryDiffHandle[$categoryDiffHandle - 1]);
                            $categoryDiffSorted.push($currentSlice);
                          }

                          // get the largest child number, useful for doing the loop for scattering later
                          if ($currentSlice && $largestChildNum < $currentSlice.length) {
                            $largestChildNum = $currentSlice.length;
                          }
                        });

                        // with that new array, scatter the array item evenly, based on category
                        var iSize = $categoryDiffSorted.length;
                        var i1 = 0;
                        var i2 = 0;
                        var $combined_feed_pretty = [];

                        // $categoryDiffSorted[CHILD][GRANDCHILD]
                        while (i2 < $largestChildNum) {
                          if (typeof $categoryDiffSorted[i1][i2] !== "undefined") {
                            $combined_feed_pretty.push($categoryDiffSorted[i1][i2]);
                          }

                          if (i1 < (iSize - 1)) { // ---- when it is not last CHILD of $categoryDiffSorted
                            i1++; // goto the next CHILD of $categoryDiffSorted
                          } else { // ---- when reaching last CHILD of $categoryDiffSorted
                            i1 = 0; // loop back to first CHILD of $categoryDiffSorted
                            i2++; // goto the next GRANDCHILD of $categoryDiffSorted
                          }
                        }
                        $combined_feed = $combined_feed_pretty;

                        // only balanced on the first fold
                        var $categoryDiffHandle = [];
                        var $combined_feed_fetch = [];
                        $.each($combined_feed, function(iii, vvv) {
                          if (iii > 0 && (vvv[$category] !== $combined_feed[iii - 1][$category])) {
                            $combined_feed_fetch.push(vvv);
                            $categoryDiffHandle.push(iii);
                          }
                        });
                        /*
												// only balanced on the first fold
												var $categoryDiffHandle = [];
												var $combined_feed_fetch = [];
												$.each($combined_feed, function (iii, vvv) {
													if(iii>0 && (vvv[$category] !== $combined_feed[iii-1][$category])){
														$combined_feed_fetch.push(vvv);
														$categoryDiffHandle.push(iii);
													}
												});

												$.each($categoryDiffHandle, function (i, v) {
													$combined_feed.splice(v,1);
												});

												$.each($combined_feed_fetch, function (i, v) {
													$combined_feed.splice(1, 0, v);
												});
												*/
                        $.each($categoryDiffHandle, function(i, v) {
                          $combined_feed.splice(v, 1);
                        });
                        /*
												// only balanced on the first fold
												var $categoryDiffHandle = [];
												var $combined_feed_fetch = [];
												$.each($combined_feed, function (iii, vvv) {
													if(iii>0 && (vvv[$category] !== $combined_feed[iii-1][$category])){
														$combined_feed_fetch.push(vvv);
														$categoryDiffHandle.push(iii);
													}
												});

												$.each($categoryDiffHandle, function (i, v) {
													$combined_feed.splice(v,1);
												});

												$.each($combined_feed_fetch, function (i, v) {
													$combined_feed.splice(1, 0, v);
												});
												*/
                        $.each($combined_feed_fetch, function(i, v) {
                          $combined_feed.splice(1, 0, v);
                        });

                      }
                    }
                    if ($limit != -1) {
                      $combined_feed = $combined_feed.slice(0, $limit);
                    }

                    // remove duplicate items

                    var myArray = $combined_feed;
                    var newArray = [];

                    $.each(myArray, function(key, value) {
                      var exists = false;
                      $.each(newArray, function(k, val2) {
                        if (value.ID == val2.ID) {
                          exists = true
                        };
                      });
                      if (exists == false) {
                        newArray.push(value);
                      }
                    });




                    console.log('~~~~~~~~~~~~~~~~~~~~~~~~~');
                    console.log(newArray);
                    console.log('~~~~~~~~~~~~~~~~~~~~~~~~~');


                    $combined_feed = newArray;

                    $combined_feed.FileNames = FileNames;

                    $this.html(template($combined_feed));

                    //runHook('templateMultiFeed_');
                    main_init();
                    console.log("Template Rendering is DONE ---------");
                    $this.trigger('handlebar_rendered');
                    if (typeof custom_init !== 'undefined' && $.isFunction(custom_init)) {
                      custom_init();
                    }
                  }

                  if ($item_checker == $limit) {
                    return false;
                  }
                });

                if ($item_checker == $limit) {
                  return false;
                }
              });

            } else {
              $.getScript($feed, function(data, textStatus, jqxhr) {

                if (typeof $this.attr('data-scope') !== typeof undefined && $this.attr('data-scope') !== false) {
                  feed_data = feed_data[$this.attr('data-scope')];
                }

                console.log("Rendering feed into template...");

                if (typeof $this.attr('data-value') !== typeof undefined && $this.attr('data-value') !== false) {
                  var $value = $this.attr('data-value');
                  $value = window[$value];
                  console.log("Template read data-value");
                  $this.html(template($value));
                } else {
                  if (typeof $sort !== typeof undefined && $sort !== false) {
                    if ('items' in feed_data) {
                      feed_data.items.sort(function(a, b) {
                        return a[$sort] - b[$sort];
                      });
                    } else {

                      feed_data = feed_data.sort(function(a, b) {
                        var aa = new Date(a[$sort]).getTime() / 1000;
                        var bb = new Date(b[$sort]).getTime() / 1000;

                        console.log('aa: ' + aa);
                        console.log('bb: ' + bb);

                        aa = parseInt(aa) || 0;
                        bb = parseInt(bb) || 0;
                        return bb - aa;
                      });
                    }
                    console.log('Sorted by: ' + $sort);
                  }

                  if ($limit != -1) {
                    feed_data = feed_data.slice(0, $limit);
                  }

                  console.log('======================================');
                  console.log('======================================');
                  console.log('======================================');
                  console.log(feed_data);
                  console.log('======================================');
                  console.log('======================================');
                  console.log('======================================');

                  $this.html(template(feed_data));
                }
                main_init();
                $this.trigger('handlebar_rendered');
                if (typeof custom_init !== 'undefined' && $.isFunction(custom_init)) {
                  custom_init();
                }

                console.log("--------- Template Rendering is DONE ---------");
              });
            }
          }
        } else if (typeof $this.attr('data-value') !== typeof undefined && $this.attr('data-value') !== false) {
          var $value = $this.attr('data-value');
          $value = window[$value];
          console.log("Template read data-value");
          $this.html(template($value));
        } else {
          console.log("Template NOT reading any feed data");
          $this.html(template(''));
          console.log("Template Rendering is DONE ---------");
          $this.trigger('handlebar_rendered');

          if (typeof custom_init !== 'undefined' && $.isFunction(custom_init)) {
            custom_init();
          }
        }
      } else {
        console.log("Template is delegated");
      }
    });
  }

  Handlebars.registerHelper('substr', function(needle, haystack) {
    needle = Handlebars.escapeExpression(needle);
    haystack = Handlebars.escapeExpression(haystack);
    return (haystack.indexOf(needle) > -1) ? true : false;
  });
  Handlebars.registerHelper('strreplace', function(str, search, replace) {
    return str.replace(search, replace);
  });
  Handlebars.registerHelper("html_decode", function(value, options) {
    if (value.indexOf('<p>') == 0) {
      //console.log(value);
      value = value.replace(/&#38;quot;/g, '"');
      return value;
    } else {
      value = value.replace('<br>', "|br|");
      value = $("<div/>").html(value).text();
      value = value.replace(/&quot;/g, '"');
      value = value.replace(/\|br\|/g, '<br>');
      //console.log(value);
      return value;
    }
  });

  Handlebars.registerHelper("html_decode_v2", function(value, options) {
    if (value.indexOf('<p>') == 0) {
      //console.log(value);
      value = value.replace(/&#38;quot;/g, '"');
      return $('<div/>').html(value);
    } else {
      value = value.replace('<br>', "|br|");
      value = $("<div/>").html(value).text();
      value = value.replace(/&quot;/g, '"');
      value = value.replace(/\|br\|/g, '<br>');
      //console.log(value);
      return $('<div/>').html(value);
    }
  });

  Handlebars.registerHelper("html_plaintext", function(value, options) {
    return $("<div/>").html(value).text()
  });
  Handlebars.registerHelper("html_safe", function(value, options) {
    value = value.replace(/&#38;quot;&#34;/g, '"');
    value = value.replace(/&#34;/g, "'");
    return value;
  });
  Handlebars.registerHelper("inc", function(value, options) {
    return parseInt(value) + 1;
  });
  Handlebars.registerHelper("factor", function(value, options) {
    return parseInt(value) % 4 + 1;
  });
  Handlebars.registerHelper("trim_safe", function(value, options) {
    return value.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "");
  });
  Handlebars.registerHelper("css_safe", function(value, options) {

    if (typeof value !== "undefined" && value != "") {
      return value.replace(/[^a-z0-9]/g, function(s) {
        var c = s.charCodeAt(0);
        if (c == 32) return '-';
        if (c >= 65 && c <= 90) return s.toLowerCase();
        return '__' + ('000' + c.toString(16)).slice(-4);
      });
    } else {
      return value;
    }
  });
  Handlebars.registerHelper("css_safe_split", function($value, options) {

    if (typeof $value !== "undefined" && $value != "") {
      $value = $value.replace(/[^a-z0-9,\/]/g, function(s) {
        var c = s.charCodeAt(0);
        if (c == 32) return '-';
        if (c >= 65 && c <= 90) return s.toLowerCase();
        return '';
      });

      $value = $value.split(',-').join(' ');
      $value = $value.split('/-').join(' ');
      $value = $value.split('/').join(' ');
      $value = $value.split('-and-').join(' ');
      $value = $value.split('--').join('-');

      return $value;
    } else {
      return $value;
    }
  });
  Handlebars.registerHelper("css_safe_trim", function(value, options) {
    value = value.replace(/\%20/g, "");
    value = value.replace(/\.[^/.]+$/, "");
    value = $.trim(value.replace(/<\/?i[^>]*>/g, ""));
    return value.replace(/[^a-z0-9]/g, function(s) {
      var c = s.charCodeAt(0);
      if (c == 32) return '-';
      if (c >= 65 && c <= 90) return s.toLowerCase();
      return '__' + ('000' + c.toString(16)).slice(-4);
    });
  });
  Handlebars.registerHelper("prettyFileName", function(value, options) {
    value = value.replace(/\.[^/.]+$/, "");
    value = value.replace(/\%20/g, ' ');
    return value;
  });
  Handlebars.registerHelper('ifObject', function(item, options) {
    if (typeof item === "object") {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('each_sort_key', function(context, options) {
    var ret = '';
    Object.keys(context).sort().forEach(function($key) {
      var $arr = context[$key];
      $arr['key'] = $key;
      ret = ret + options.fn($arr);
    });
    return ret
  });

  Handlebars.registerHelper('each_sort_key_v2', function(context, options) {
    var ret = '';
    var obj = {};

    Object.keys(context).sort().forEach(function($key) {
      var $arr = context[$key];
      $arr['key'] = $key;
      ret = ret + options.fn($arr);
      obj[$key] = $arr;
    });

    console.log("obj is ", obj);
    return obj
  });




  Handlebars.registerHelper('bold_pre_dash', function(value, options) {
    value = value.replace(/\u2013|\u2014/g, "-");
    var parts = value.split(' - ');

    if (value != parts[0]) {
      var $part_0 = '<strong>' + parts[0] + '</strong><br>';
      return $part_0 + parts[1];
    } else {
      var parts_i = value.split(', ');
      if (value != parts_i[0]) {
        var $part_i_0 = '<strong>' + parts_i[0] + '</strong><br>';
        return $part_i_0 + parts_i[1];
      } else {
        return value;
      }
    }
  });
  Handlebars.registerHelper('bold_f3', function(value, options) {
    var $f3 = value.split(/\s+/).slice(0, 3);

    var $f3_holder;

    if ($f3[2] == 'of') {
      $f3_holder = $f3[0] + " " + $f3[1] + " ";
    } else {
      $f3_holder = $f3.join(" ");
    }


    var $after_f3 = value.replace($f3_holder, '');

    value = '<strong>' + $f3_holder + '</strong>' + $after_f3;

    return value;
  });
  Handlebars.registerHelper('objectLength', function(value, options) {
    return Object.keys(value).length;
  });
  Handlebars.registerHelper('obj_only1', function(value, options) {
    var fnTrue = options.fn,
      fnFalse = options.inverse;
    if (Object.keys(value).length == 1) {
      return fnTrue(this);
    } else {
      return fnFalse(this);
    }
  });
  Handlebars.registerHelper('obj_only2', function(value, options) {
    var fnTrue = options.fn,
      fnFalse = options.inverse;
    if (Object.keys(value).length == 2) {
      return fnTrue(this);
    } else {
      return fnFalse(this);
    }
  });
  Handlebars.registerHelper('if_popup', function(value, options) {
    if (value == "#popup") {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_video', function(value, options) {
    if (value == "#video") {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_iframe', function(value, options) {
    if (typeof value !== "undefined" && value.match("^\<iframe")) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('is_first_and_second', function(index, options) {
    if (index == 2 || index == 1) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('is_not_first', function(index, options) {
    if (index > 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('is_first_five', function(index, options) {
    if (index < 6) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('is_second', function(index, options) {
    if (index == 1) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('is_third', function(index, options) {
    if (index == 2) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('is_fourth', function(index, options) {
    if (index == 3) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_every_third', function(index, options) {
    if ((index + 1) >= 3 && (index + 1) % 3 == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_after_every_third', function(index, options) {
    if ((index + 1) % 3 == 1) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_every_fourth_and_start', function(index, options) {
    if ((index + 1) % 4 == 0 || index == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_after_every_fourth', function(index, options) {
    if ((index + 1) % 4 == 1) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_every_fourth', function(index, options) {
    if ((index + 1) % 4 == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_every_fifth_and_start', function(index, options) {
    if ((index + 1) % 5 == 0 || index == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_every_fifth', function(index, options) {
    if ((index + 1) % 5 == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });

  Handlebars.registerHelper('if_every_nineth_and_start', function(index, options) {
    if ((index + 1) % 9 == 0 || index == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_after_every_nineth', function(index, options) {
    if ((index + 1) % 9 == 1) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_every_nineth', function(index, options) {
    if ((index + 1) % 9 == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });

  Handlebars.registerHelper('if_after_every_fifth', function(index, options) {
    if ((index + 1) % 5 == 1) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });

  Handlebars.registerHelper('if_every_sixth', function(index, options) {
    if ((index + 1) % 6 == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });

  Handlebars.registerHelper('if_after_every_sixth', function(index, options) {
    if ((index + 1) % 6 == 1) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });

  Handlebars.registerHelper('if_every_tenth', function(index, options) {
    if (index > 10 && (index + 1) % 10 == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('if_every_eleventh_and_start', function(index, options) {
    if ((index + 1) % 10 == 1 || index == 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });

  Handlebars.registerHelper('if_larger_than_one_hundred', function(index, options) {
    if ((index + 1) > 100) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('cleanText', function(string) {
    return $(string).text();
  });
  Handlebars.registerHelper('prettyDate', function(date_string) {
    var formattedDate = new Date(date_string);
    var d = formattedDate.getDate();
    if (d < 10) {
      d = "0" + d;
    }

    var m = months_short[formattedDate.getMonth()];

    var y = formattedDate.getFullYear();

    return (d + " " + m + " " + y);
  });
  Handlebars.registerHelper('prettyDate1', function(date_string) {
    var formattedDate = new Date($('<div>' + date_string + '</div>').text());
    var d = formattedDate.getDate();
    if (d < 10) {
      d = "0" + d;
    }

    var m = months_short[formattedDate.getMonth()];

    var y = formattedDate.getFullYear();

    return ("<b>" + d + "</b>" + " " + m + " " + y);
  });
  Handlebars.registerHelper('time_MMM', function(date_string) {
    var from = date_string.split("/"); // need to add more separator if needed
    var d = new Date(from[2], from[1] - 1, from[0]);
    var m = d.getMonth();
    return months_short[m];
  });
  Handlebars.registerHelper('time_YYYY', function(date_string) {
    var from = date_string.split("/"); // need to add more separator if needed
    var d = new Date(from[2], from[1] - 1, from[0]);
    return d.getFullYear();
  });
  Handlebars.registerHelper('time_MMM_css_safe', function(date_string) {
    var from = date_string.split("/"); // need to add more separator if needed
    var d = new Date(from[2], from[1] - 1, from[0]);
    var m = d.getMonth();
    return css_safe(months_short[m].toString());
  });
  Handlebars.registerHelper('time_YYYY_css_safe', function(date_string) {
    var from = date_string.split("/"); // need to add more separator if needed
    var d = new Date(from[2], from[1] - 1, from[0]);
    return css_safe(d.getFullYear().toString());
  });
  Handlebars.registerHelper('smart_video_thumbnail', function(myImage, myVideo) {
    if (!myImage || myImage == '') {
      myImage = 'empty';
    }
    if (myImage == 'empty') {
      return 'https://img.youtube.com/vi/' + YouTubeGetID(myVideo) + '/0.jpg';
    } else {
      return myImage;
    }
  });

  Handlebars.registerHelper("x", function(expression, options) {
    var result;
    // you can change the context, or merge it with options.data, options.hash
    var context = this;
    // yup, i use 'with' here to expose the context's properties as block variables
    // you don't need to do {{x 'this.age + 2'}}
    // but you can also do {{x 'age + 2'}}
    // HOWEVER including an UNINITIALIZED var in a expression will return undefined as the result.
    with(context) {
      result = (function() {
        try {
          return eval(expression);
        } catch (e) {
          console.warn('Expression: {{x \'' + expression + '\'}}\nJS-Error: ', e, '\nContext: ', context);
        }
      }).call(context); // to make eval's lexical this=context
    }
    return result;
  });

  Handlebars.registerHelper("xif", function(expression, options) {
    return Handlebars.helpers["x"].apply(this, [expression, options]) ? options.fn(this) : options.inverse(this);
  });

  Handlebars.registerHelper('ifEquals', function(arg1, arg2, options) {
    return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
  });

  Handlebars.registerHelper('prezero', function(string, number_of_zero) {
    var get_number_of_zero = 2;
    if (typeof number_of_zero !== typeof undefined && number_of_zero !== false && !isNaN(number_of_zero)) {
      get_number_of_zero = parseInt(number_of_zero);
    }
    var num = '' + string;
    while (num.length < get_number_of_zero) {
      num = '0' + num;
    }
    return num;
  });

  Handlebars.registerHelper('prettyPercent', function(num, number_of_decimal) {
    if (num.slice(-1) == '%') {
      num = num.slice(0, -1);
      num = num / 100;
    }
    var get_number_of_decimal = 2;
    if (typeof number_of_decimal !== typeof undefined && number_of_decimal !== false && !isNaN(number_of_decimal)) {
      get_number_of_decimal = parseInt(number_of_decimal);
    }
    var num = num * 100;
    return num.toFixed(get_number_of_decimal);
  });

  Handlebars.registerHelper('prettyNumber', function(num, number_of_decimal) {
    var get_number_of_decimal = 2;
    if (typeof number_of_decimal !== typeof undefined && number_of_decimal !== false && !isNaN(number_of_decimal)) {
      get_number_of_decimal = parseInt(number_of_decimal);
    }
    num = parseFloat(num);
    num = num.toFixed(get_number_of_decimal);
    num = addCommas(num);
    return num;
  });

  Handlebars.registerHelper('prezero_start_one', function(string, number_of_zero) {
    var get_number_of_zero = 2;
    if (typeof number_of_zero !== typeof undefined && number_of_zero !== false && !isNaN(number_of_zero)) {
      get_number_of_zero = parseInt(number_of_zero);
    }
    var num = parseInt(string) + 1;
    num = '' + num;
    while (num.length < get_number_of_zero) {
      num = '0' + num;
    }
    return num;
  });




  Handlebars.registerHelper("prettyArray", function(string) {
    if (typeof string !== typeof undefined && string != '') {
      string = string.replace(/:/g, ', ');
    }
    return string;
  });



  Handlebars.registerHelper("lowercase", function(value, options) {
    if (typeof value !== typeof undefined && value != '') {
      value = value.toLowerCase();
    }
    return value;
  });

  Handlebars.registerHelper("first_capital_rest_lowercase", function(value, options) {
    if (typeof value !== typeof undefined && value != '') {
      value = value.toLowerCase();
      value = value.charAt(0).toUpperCase() + value.slice(1)
    }
    return value;
  });

  Handlebars.registerHelper("lowercase_trim", function(value, option) {
    if (typeof value !== typeof undefined && value != '') {
      value = value.toLowerCase();

      var regex = new RegExp(option, "gi");
      value = value.replace(regex, "");
      //console.log('here----------------------');
      //console.log(value);
    }

    return value;
  });

  Handlebars.registerHelper("concat_string_by_hyphen", function(value, options) {
    if (typeof value !== typeof undefined && value != '') {
      value = value.replace(/\W+/g, "-").toLowerCase();
      //console.log("the value is", value);
    }
    return value;
  });

  Handlebars.registerHelper("remove_special_characters", function(value, options) {
    if (typeof value !== typeof undefined && value != '') {
      //console.log("the value inside remove_special_characters is", value);
      //value = value.replace(/[^\w\s]/gi, '');
      value = value.replace(/[^\w\s]/gi, '');
      // console.log("the value inside remove_special_characters  after is", value.split('-'));
      //console.log("the value is", value);
    }
    return value;
  });

  Handlebars.registerHelper("sumArray", function(value, options) {
    //console.log("the value inside sumArray is ", value);
    var cnt = 0;
    for (var k in value) {
      if (value.hasOwnProperty(k)) {
        //console.log("Key is " + k + ", value is" + value[k]);
        for (var key in value[k]) {
          cnt += parseInt(value[k][key]);
          //console.log("count is ", cnt);
        }
      }
    }
    return cnt;
  });

  Handlebars.registerHelper("formatWinType", function(value, options) {
    // console.log("the value inside formatWinType is ", value);
    var parts = value.split(/[^\w\s]/gi);
    var winType = '<strong>' + parts[0] + '</strong> <br> <small>' + parts[1] + '</small>';
    return winType;
  });

  Handlebars.registerHelper('randomNumber', function(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
  });

  Handlebars.registerHelper('region_code', function(string) {
    switch (string.toLowerCase()) {
      case 'china':
        string = 'CN';
        break;
      case 'india':
        string = 'IN';
        break;
      case 'korea':
        string = 'KR';
        break;
    }
    return string;
  });

  Handlebars.registerHelper('log', function(content) {
    console.log(content.fn(this));
    return '';
  });

  Handlebars.registerHelper("math", function(lvalue, operator, rvalue, options) {
    lvalue = parseFloat(lvalue);
    rvalue = parseFloat(rvalue);

    return {
      "+": lvalue + rvalue,
      "-": lvalue - rvalue,
      "*": lvalue * rvalue,
      "/": lvalue / rvalue,
      "%": lvalue % rvalue
    } [operator];
  });

  Handlebars.registerHelper('concat', function() {
     var outStr = '';
    // for (var arg in arguments) {
    //   if (typeof arguments[arg] != 'object') {
    //     outStr += arguments[arg];
    //   }
    // }
    // return outStr;
    arguments = [...arguments].slice(0, -1);
    outStr = arguments.join('');
    return outStr;
  });

  Handlebars.registerHelper('formatKeyWinsTitle', function(value) {
    value = value.replace(/['"]+/g, "");
    var str = value.replace('(', '').replace(')', '').replace(',', '').replace(' ', '').split('.').join("");
    var res = str.split(" ");
    res = res.join('-');
    return res;
  });

  Handlebars.registerHelper('assign', function(varName, varValue, options) {
    if (!options.data.root) {
      options.data.root = {};
    }
    options.data.root[varName] = varValue;
  });

  Handlebars.registerHelper('_if', function(v1, operator, v2, options) {
    switch (operator) {
      case '==':
        return (v1 == v2) ? options.fn(this) : options.inverse(this);
      case '===':
        return (v1 === v2) ? options.fn(this) : options.inverse(this);
      case '!=':
        return (v1 != v2) ? options.fn(this) : options.inverse(this);
      case '!==':
        return (v1 !== v2) ? options.fn(this) : options.inverse(this);
      case '<':
        return (v1 < v2) ? options.fn(this) : options.inverse(this);
      case '<=':
        return (v1 <= v2) ? options.fn(this) : options.inverse(this);
      case '>':
        return (v1 > v2) ? options.fn(this) : options.inverse(this);
      case '>=':
        return (v1 >= v2) ? options.fn(this) : options.inverse(this);
      case '&&':
        return (v1 && v2) ? options.fn(this) : options.inverse(this);
      case '||':
        return (v1 || v2) ? options.fn(this) : options.inverse(this);
      default:
        return options.inverse(this);
    }
  });

  Handlebars.registerHelper('substring', function(string, start, end) {
    if (end >= string.length) {
      end = string.length;
    }
    var theString = string.substring(start, end);
    return new Handlebars.SafeString(theString);
  });

  /*Check if : is present and if so parse it and return the hrefs*/
  Handlebars.registerHelper('parse_emails', function(string) {
    var result = '';
    var isValid = /[,;:]/.test(string);
    if (isValid) {
      var str = string.split(/[,;:]/);
      for (var i = 0; i < str.length; i++) {
        result += '<a href="mailto:' + str[i] + '">' + str[i] + '</a><br>';
      }
    }
    return result;
  });

  Handlebars.registerHelper('split_if_larger_than', function(string, number) {
    var result = '';
    if (string.length > number) {
      if (string.indexOf('@oracle.com') > -1) {
        var res = string.slice(0, string.indexOf('@oracle.com'));
        result += res + '<br>' + '@oracle.com';
      }
    }
    return result;
  });

    Handlebars.registerHelper('check_why_adw', function(string) {
        var outStr = '';
        var test = string;
        var easy_win_flag = false;
        var fast_win_flag = false;
        //console.log("my string is", test);
        var result = test.split(":");
        for (var tmp in result) {
            if(result[tmp] == 'WHY_EASY') {
                easy_win_flag = true;
            } else if (result[tmp] == 'WHY_FAST') {
                fast_win_flag = true;
            }
        }
        if (easy_win_flag == true && fast_win_flag == true) {
            outStr = 'why_easy why_fast';
        } else if (easy_win_flag == true && fast_win_flag == false) {
            outStr = 'why_easy';
        } else if (easy_win_flag == false && fast_win_flag == true) {
            outStr = 'why_fast';
        }
        // for (var tmp in result) {
        //     console.log("string is ", result[tmp]);
        //     if(result[tmp] == 'WHY_EASY') {
        //         outStr = 'why_easy';
        //     } else if(result[tmp] == 'WHY_FAST') {
        //         outStr = 'why_fast';
        //     }
        // }
        return outStr;
    });
}

function YouTubeGetID(url) {
  var ID = '';
  url = url.replace(/(>|<)/gi, '').split(/(vi\/|v=|\/v\/|youtu\.be\/|\/embed\/)/);
  if (url[2] !== undefined) {
    ID = url[2].split(/[^0-9a-z_\-]/i);
    ID = ID[0];
  } else {
    ID = url;
  }
  return ID;
}




addCommas = function(input) {
  // If the regex doesn't match, `replace` returns the string unmodified
  return (input.toString()).replace(
    // Each parentheses group (or 'capture') in this regex becomes an argument
    // to the function; in this case, every argument after 'match'
    /^([-+]?)(0?)(\d+)(.?)(\d+)$/g,
    function(match, sign, zeros, before, decimal, after) {

      // Less obtrusive than adding 'reverse' method on all strings
      var reverseString = function(string) {
        return string.split('').reverse().join('');
      };

      // Insert commas every three characters from the right
      var insertCommas = function(string) {

        // Reverse, because it's easier to do things from the left
        var reversed = reverseString(string);

        // Add commas every three characters
        var reversedWithCommas = reversed.match(/.{1,3}/g).join(',');

        // Reverse again (back to normal)
        return reverseString(reversedWithCommas);
      };

      // If there was no decimal, the last capture grabs the final digit, so
      // we have to put it back together with the 'before' substring
      return sign + (decimal ? insertCommas(before) + decimal + after : insertCommas(before + after));
    }
  );
};