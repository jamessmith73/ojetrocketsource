define(['accUtils','knockout', 'ojs/ojbootstrap', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider', 'ojs/ojknockouttemplateutils',
    'text!jsons/projectData.json', 'ojs/ojknockout', 'ojs/ojtable', 'ojs/ojrowexpander'],
 function(accUtils , ko, Bootstrap, FlattenedTreeDataProviderView,
    ArrayTreeDataProvider, KnockoutTemplateUtils, jsonDataStr) 
 {

    function DashboardViewModel() {
      var self = this;

      // ======= Custom code start =========================
           
          this.datasource = ko.observable();
      this.KnockoutTemplateUtils = KnockoutTemplateUtils;
      var arrayTreeDataProvider = new ArrayTreeDataProvider(JSON.parse(jsonDataStr), { keyAttributes: 'id' });
      this.datasource(new FlattenedTreeDataProviderView(arrayTreeDataProvider,
        { expanded: this.expanded })); 
            
           
      // ======= Custom code End =========================
      
      self.connected = function() { 
        document.title = "Dashboard"; 
      };

        
    }

     
    return DashboardViewModel;
  }
);
