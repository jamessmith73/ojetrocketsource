 
define(['accUtils', 'knockout', 'ojs/ojbootstrap', 'ojs/ojflattenedtreedatagriddatasource', 
'ojs/ojjsontreedatasource', 'ojs/ojknockouttemplateutils',
    'text!jsons/projectData2.json', 'ojs/ojknockout', 'ojs/ojdatagrid', 'ojs/ojrowexpander'],
 function(accUtils, ko, Bootstrap, flattenedModule, JsonTreeDataSource, KnockoutTemplateUtils, jsonDataStr) {

    function IncidentsViewModel() {
      var self = this;

      // ======= Start Copy ==================
       this.KnockoutTemplateUtils = KnockoutTemplateUtils;
      var options = {
        rowHeader: 'name',
        columns: ['resource', 'start', 'end']
      };
      this.dataSource = ko.observable();
  
      this.dataSource(new flattenedModule.FlattenedTreeDataGridDataSource(
        new JsonTreeDataSource(JSON.parse(jsonDataStr)), options));

      // ======= End Copy ==================

      self.connected = function() { 
        document.title = "Incidents"; 
      };

        
    }

     
    return IncidentsViewModel;
  }
);
