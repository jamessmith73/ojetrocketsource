define(['accUtils', 'knockout', 'ojs/ojbootstrap', 'text!jsons/seriesOneData.json', 'ojs/ojarraydataprovider', 'ojs/ojknockout', 'ojs/ojtimeline'],
 function(accUtils, ko, Bootstrap, data, ArrayDataProvider) {

    function TimelineViewModel() {
      var self = this; 

      // ======= Start Copy 
      this.dataProvider = new ArrayDataProvider(JSON.parse(data), {keyAttributes: 'id'}); 
        this.currentDateString = "Feb 1, 2010";
        var currentDate = new Date(this.currentDateString).toISOString();
        this.referenceObjects = [{value: currentDate}];
      // ======= End Copy

      self.connected = function() { 
        document.title = "Timeline"; 
      };

       
    } 
    return TimelineViewModel;
  }
);
