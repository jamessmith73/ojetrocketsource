/**
 * @license
 * Copyright (c) 2014, 2019, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * @ignore
 */
/*
 * Your about ViewModel code goes here
 */
define(['accUtils', 'knockout', 'ojs/ojbootstrap', 'ojs/ojattributegrouphandler',
    'text!jsons/usaMeanIncomeSubregion.json', 
    'ojs/ojarraytreedataprovider', 'ojs/ojknockout', 'ojs/ojtreemap'],
 function(accUtils, ko, Bootstrap, attributeGroupHandler, jsonData, ArrayTreeDataProvider) {

    function TreemapViewModel() {
      var self = this;
      // Below are a set of the ViewModel methods invoked by the oj-module component.
      // Please reference the oj-module jsDoc for additional information.

        var handler = new attributeGroupHandler.ColorAttributeGroupHandler();
        var data = JSON.parse(jsonData);
        this.treemapData= new ArrayTreeDataProvider(data, {keyAttributes: 'label', childrenAttribute: "nodes"});
        this.getColor = function(meanIncome){
          if (meanIncome < 45000) // 1st quartile
            return handler.getValue('1stQuartile');
          else if (meanIncome < 49000) // 2nd quartile
            return handler.getValue('2ndQuartile');
          else if (meanIncome < 56000) // 3rd quartile
            return handler.getValue('3rdQuartile');
          else
            return handler.getValue('4thQuartile');
        };
        this.getShortDesc = function(label, population, meanIncome) {
          return "&lt;b&gt;" + label +
                 "&lt;/b&gt;&lt;br/&gt;Population: " + population +
                 "&lt;br/&gt;Income: " + meanIncome;
        };
       
      self.connected = function() {
        
        document.title = "About";
        // Implement further logic if needed
      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      self.disconnected = function() {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      self.transitionCompleted = function() {
        // Implement if needed
      };



      
    }

    /*
     * Returns an instance of the ViewModel providing one instance of the ViewModel. If needed,
     * return a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.
     */
    return TreemapViewModel;
  }
);
