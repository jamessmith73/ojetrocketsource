define(['accUtils'],
 function(accUtils) {

    function Comp5ViewModel() {
      var self = this;

      // Main code starts here 
     
      // Main code ends here 
      
      self.connected = function() { 
        document.title = "Chart";
        // Implement further logic if needed
      };  
       
    }
 
    return Comp5ViewModel;
  }
);
